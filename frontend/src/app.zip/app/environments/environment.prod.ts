export const environment = {
    production: true,
    apiUrl: "http://localhost:8090" // Change to real backend URL
  };
  